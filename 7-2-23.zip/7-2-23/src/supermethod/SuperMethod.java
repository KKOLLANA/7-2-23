package supermethod;

public class SuperMethod {

	public static void main(String[] args) {

		Child c = new Child(40,30,20,10);
		c.f1();
		c.displayDetails();
	}

}
