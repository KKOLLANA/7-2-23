package hierarchicalinheritance;

public class Bike extends Vehicle {

}
