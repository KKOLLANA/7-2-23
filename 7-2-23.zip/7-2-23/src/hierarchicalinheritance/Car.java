package hierarchicalinheritance;

public class Car extends Vehicle {
@Override
	String fuel() {
		return "Desil";
}
}