package hierarchicalinheritance;

public class Vehicle {

	String fuel() {
		return "petrol";
		
	}
}
