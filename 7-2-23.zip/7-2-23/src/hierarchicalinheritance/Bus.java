package hierarchicalinheritance;

public class Bus extends Vehicle {

	String fuel() {
		return "Cng";
}
}