package superKeyword;

public class Super {

	public static void main(String[] args) {
		Child c= new Child();
		c.f1();

	}

}
