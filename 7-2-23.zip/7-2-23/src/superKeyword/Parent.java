package superKeyword;

public class Parent {
	
	void f1() {
		System.out.println("parent class f1");
	}

}
